函数座位参数不用带小括号

1. addEventListener
2. setTimeout
3. then