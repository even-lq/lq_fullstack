## EventBus

存储事件用Map()：

因为map的key可以是任何东西